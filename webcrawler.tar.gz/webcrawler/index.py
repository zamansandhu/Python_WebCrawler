import requests
from bs4 import BeautifulSoup


def scrap_spider(max_pages):
    page = 1
    while page <= max_pages:
        url = 'http://rightproperty.pk/sale' + str(page)
        source = requests.get(url)
        plain_text = source.text
        soup_object = BeautifulSoup(plain_text, "html.parser")
        for link in soup_object.find_all('a'):
            href = link.get('href')
            # title = link.string
            print(href)
            # print(title)
            # print(link.get_text())
            # print(link.p('class'))
            get_single_page(href)
        page += 1
def get_single_page(item_url):
    source = requests.get(item_url)
    plain_text = source.text
    soup_object = BeautifulSoup(plain_text, "html.parser")
    for item_name in soup_object.find_all('div', {'class':'head'}):
        print(item_name.string)
    for link in soup_object.find_all('a'):
        href = link.get('href')
        print(href)



scrap_spider(3)
